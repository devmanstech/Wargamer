<div class="row">
<div class="col-lg-12">
  <div class="panel panel-primary" data-collapsed="0">
    <div class="panel-heading">
      <div class="panel-title">
        <?php echo get_phrase('history'); ?>
      </div>
    </div>
    <div class="panel-body">

    </div>
  </div>
</div><!-- end col-->
</div>
