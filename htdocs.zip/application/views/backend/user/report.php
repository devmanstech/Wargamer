<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title">
                    <?php echo get_phrase('report'); ?>
                </div>
            </div>
            <div class="panel-body">
        </div>
    </div>
</div><!-- end col-->
</div>


<div class="row ">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
                <h4 class="mb-3 header-title"><?php echo get_phrase('report'); ?></h4>

            </table>
        </div> <!-- end card body-->
    </div> <!-- end card -->
</div><!-- end col-->
</div>
