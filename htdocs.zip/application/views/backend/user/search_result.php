
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary" data-collapsed="0">
            <div class="panel-heading">
                <div class="panel-title">
                    <?php echo get_phrase('search_result'); ?>
                </div>
            </div>
            <div class="panel-body">
                Sorry , It is coming soon.
            </div>
        </div>
    </div><!-- end col-->
</div>

