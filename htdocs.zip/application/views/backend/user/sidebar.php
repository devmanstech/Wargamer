<div class="panel-primary" style="text-align-last: center;vertical-align: middle">
    <div class="row">
        <div class="col-lg-12" style="padding-top: 20px">

            <?php
            $button_name = isset($search_button_name) ?  $search_button_name : 'start' ;

            ?>

            <a href="<?php echo site_url('user/search/'.$button_name) ?>" class="btn btn-info" style="width: 80%">
                <?php

                echo "Search ", $button_name;

                ?>
            </a>
        </div>
    </div>

    <hr>


    <div class="row" style="padding-bottom: 20px">
        <div class="column">
            <span>Games Played Today</span>
        </div>


        <div class="column">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
        </div>
        <div class="column">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
        </div>
        <div class="column">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
        </div>
        <div class="column">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
            <img src="../../../../assets/backend/images/admin.png" width="30px">
        </div>
    </div>



</div>

